package dev.glitchreflections.tv;

import android.content.Context;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

final class Catalog {
  static final class Icon {
    String id, label, resource, thumbnail, category, status;
    int drawable, thumb;
    Icon(Context c, JSONObject j) {
      id=j.optString("id"); label=j.optString("label",j.optString("name"));
      resource=j.optString("resource"); thumbnail=j.optString("thumbnail");
      category=j.optString("category","Other"); status=j.optString("status","Manual");
      if(id.equals("ic_pack_identity")) label="Glitch Reflections";
      drawable=c.getResources().getIdentifier(resource,"drawable",c.getPackageName());
      thumb=c.getResources().getIdentifier(thumbnail,"drawable",c.getPackageName());
    }
  }
  final ArrayList<Icon> icons=new ArrayList<>();
  final ArrayList<String> categories=new ArrayList<>();
  Catalog(Context c) throws Exception {
    JSONObject j=new JSONObject(read(c,"catalog.json"));
    JSONArray all=j.getJSONArray("icons");
    for(int n=0;n<all.length();n++) icons.add(new Icon(c,all.getJSONObject(n)));
    Collections.sort(icons,(a,b)->a.label.compareToIgnoreCase(b.label));
    categories.add("All categories");
    JSONArray cats=j.getJSONArray("categories");
    for(int n=0;n<cats.length();n++) categories.add(cats.getJSONObject(n).getString("name"));
  }
  static String read(Context c,String name) throws IOException {
    try(InputStream in=c.getAssets().open(name);ByteArrayOutputStream out=new ByteArrayOutputStream()) {
      byte[] buf=new byte[8192]; int n;while((n=in.read(buf))!=-1) out.write(buf,0,n);
      return new String(out.toByteArray(),StandardCharsets.UTF_8);
    }
  }
  ArrayList<Icon> filter(String text,String category,boolean reverse) {
    ArrayList<Icon> result=new ArrayList<>();
    String q=text.trim().toLowerCase(Locale.ROOT);
    for(Icon i:icons) if((category.equals("All categories")||i.category.equals(category)) &&
      (i.label.toLowerCase(Locale.ROOT).contains(q)||i.id.contains(q))) result.add(i);
    if(reverse) Collections.reverse(result);
    return result;
  }
  Icon find(String id) {for(Icon i:icons) if(i.id.equals(id)) return i;return icons.get(0);}
}
