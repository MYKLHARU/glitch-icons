package dev.glitchreflections.tv;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.os.*;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.util.*;
import java.util.concurrent.*;

/** A native, offline Android TV catalogue designed for a five-way remote. */
public final class MainActivity extends Activity {
  static final int BG=0xff0a0c10,PANEL=0xff11151b,LINE=0xff2a3039,INK=0xfff1f2ed,
    MUTED=0xff9ba4ae,RED=0xffff4455,CYAN=0xff5ce8ff;
  static final String LAUNCHER="com.spocky.projengmenu";
  FrameLayout root; Catalog catalog; final ExecutorService decoder=Executors.newFixedThreadPool(2);
  final ArrayList<ImageView> images=new ArrayList<>();
  final ArrayList<Drawable> running=new ArrayList<>();
  float scale=1,ox,oy; int screen=0,page=0,generation=0,previewReturn=1;
  String query="",category="All categories",lastFocusedIcon="";
  boolean reverse=false,motion=true,picking=false,foreground=true;
  Catalog.Icon selected; Button motionButton; ArrayList<Button> nav=new ArrayList<>();
  ArrayList<View> cards=new ArrayList<>(); Button previous,next;
  ArrayList<Catalog.Icon> filtered=new ArrayList<>();

  @Override public void onCreate(Bundle state) {
    super.onCreate(state);
    getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN|
      View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|
      View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|
      View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    motion=getPreferences(0).getBoolean("motion",true);
    String action=getIntent().getAction();
    picking=Intent.ACTION_GET_CONTENT.equals(action)||Intent.ACTION_PICK.equals(action)||
      (action!=null&&action.endsWith("ACTION_PICK_ICON"));
    if(state!=null) {
      screen=state.getInt("screen");page=state.getInt("page");query=state.getString("query","");
      category=state.getString("category","All categories");reverse=state.getBoolean("reverse");
      previewReturn=state.getInt("previewReturn",1);lastFocusedIcon=state.getString("focus","");
    } else if(picking) screen=1;
    try {catalog=new Catalog(this);}
    catch(Exception e) {new AlertDialog.Builder(this).setTitle("Collection unavailable")
      .setMessage("Please reinstall Glitch Reflections TV to restore its artwork.")
      .setPositiveButton("Close",(d,w)->finish()).show();return;}
    if(state!=null&&state.containsKey("selected"))selected=catalog.find(state.getString("selected"));
    if(screen==4&&selected==null)screen=1;
    root=new FrameLayout(this);root.setBackgroundColor(BG);setContentView(root);
    root.post(()->{scale=Math.min(root.getWidth()/960f,root.getHeight()/540f);
      ox=(root.getWidth()-960*scale)/2;oy=(root.getHeight()-540*scale)/2;show(screen,null);});
  }
  @Override protected void onSaveInstanceState(Bundle b) {
    super.onSaveInstanceState(b);b.putInt("screen",screen);b.putInt("page",page);
    b.putString("query",query);b.putString("category",category);b.putBoolean("reverse",reverse);
    b.putInt("previewReturn",previewReturn);b.putString("focus",lastFocusedIcon);
    if(selected!=null)b.putString("selected",selected.id);
  }
  int px(float value){return Math.round(value*scale);}
  <T extends View> T place(T v,float x,float y,float w,float h) {
    FrameLayout.LayoutParams p=new FrameLayout.LayoutParams(px(w),px(h));
    p.leftMargin=Math.round(ox+x*scale);p.topMargin=Math.round(oy+y*scale);root.addView(v,p);return v;
  }
  TextView text(String s,float size,int color,boolean bold) {
    TextView t=new TextView(this);t.setText(s);t.setTextColor(color);
    t.setTextSize(TypedValue.COMPLEX_UNIT_PX,size*scale);
    t.setTypeface(Typeface.create(bold?"sans-serif-black":"sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));
    t.setIncludeFontPadding(false);return t;
  }
  TextView label(String s,float x,float y,float w,float h,float size,int color,boolean bold) {
    return place(text(s,size,color,bold),x,y,w,h);
  }
  void chromatic(String s,float x,float y,float w,float h,float size) {
    label(s,x-1,y,w,h,size,RED,true).setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
    label(s,x+1,y,w,h,size,CYAN,true).setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
    label(s,x,y,w,h,size,INK,true);
  }
  void mono(String s,float x,float y,float w,int color) {
    TextView t=label(s,x,y,w,22,10,color,false);t.setTypeface(Typeface.MONOSPACE);t.setLetterSpacing(.08f);
  }
  void line(float x,float y,float w) {View v=new View(this);v.setBackgroundColor(LINE);place(v,x,y,w,1);}
  GradientDrawable shape(int fill,int stroke,int width) {
    GradientDrawable d=new GradientDrawable();d.setColor(fill);if(width>0)d.setStroke(px(width),stroke);return d;
  }
  void stopImages() {
    generation++;for(Drawable d:running)if(d instanceof Animatable)((Animatable)d).stop();running.clear();
    for(ImageView image:images){image.setTag(null);image.setImageDrawable(null);}images.clear();
  }
  void show(int target,String focusTag) {
    stopImages();screen=target;root.removeAllViews();nav.clear();cards.clear();
    header();if(screen==0)home();else if(screen==1)library();else if(screen==2)applyScreen();
    else if(screen==3)support();else detail();
    line(40,503,880);mono(picking?"SELECT AN ICON  /  BACK TO CANCEL":"D-PAD  MOVE     SELECT  OPEN     BACK  RETURN",40,515,600,MUTED);
    mono("GLITCH REFLECTIONS  /  TV 2.0",714,515,220,MUTED);
    // Restore remote focus even when the previous Activity used pointer input.
    if(focusTag!=null&&root.findViewWithTag(focusTag)!=null)root.findViewWithTag(focusTag).requestFocusFromTouch();
    else if(screen==1&&!cards.isEmpty())cards.get(0).requestFocusFromTouch();
    else if(screen==4&&root.findViewWithTag("detailAction")!=null)root.findViewWithTag("detailAction").requestFocusFromTouch();
    else if(root.findViewWithTag("primary")!=null)root.findViewWithTag("primary").requestFocusFromTouch();
    else nav.get(Math.min(screen,3)).requestFocusFromTouch();
  }
  Button button(String s,float x,float y,float w,float h,boolean primary,Runnable action) {
    Button b=new Button(this);b.setId(View.generateViewId());b.setText(s);b.setAllCaps(false);
    b.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL));b.setMinWidth(0);b.setMinimumWidth(0);
    b.setMinHeight(0);b.setMinimumHeight(0);b.setPadding(px(10),0,px(10),0);
    b.setTextSize(TypedValue.COMPLEX_UNIT_PX,13*scale);b.setSingleLine(true);b.setEllipsize(TextUtils.TruncateAt.END);
    b.setStateListAnimator(null);b.setFocusable(true);
    b.setTextColor(primary?BG:INK);b.setBackground(shape(primary?INK:PANEL,LINE,1));
    b.setOnFocusChangeListener((v,f)->{
      b.setBackground(shape(f?CYAN:primary?INK:PANEL,f?CYAN:LINE,f?2:1));
      b.setTextColor(f||primary?BG:INK);b.setElevation(f?px(4):0);
    });b.setOnClickListener(v->action.run());place(b,x,y,w,h);return b;
  }
  void header() {
    chromatic("G//R",40,30,72,32,27);
    label("GLITCH\nREFLECTIONS",119,33,220,36,12,INK,true).setLetterSpacing(.12f);
    String[] names={"Home","Collection","Apply","Support"};float[] xs={414,489,601,676};float[] ws={67,104,67,78};
    for(int n=0;n<4;n++){final int dest=n;Button b=button(names[n],xs[n],29,ws[n],36,false,()->show(dest,null));
      if(screen==n){b.setTextColor(CYAN);b.setBackground(shape(PANEL,CYAN,1));}nav.add(b);}
    motionButton=button(motion?"Motion: on":"Motion: off",772,29,148,36,false,()->{
      motion=!motion;getPreferences(0).edit().putBoolean("motion",motion).apply();show(screen,"motion");});
    motionButton.setTag("motion");nav.add(motionButton);line(40,84,880);
  }
  ImageView image(int resource,float x,float y,float w,float h) {
    ImageView i=new ImageView(this);i.setScaleType(ImageView.ScaleType.FIT_CENTER);images.add(i);
    if(resource!=0)i.setImageResource(resource);return place(i,x,y,w,h);
  }
  void animate(ImageView view,Catalog.Icon icon) {
    if(!motion||!foreground||icon.drawable==0)return;
    Object token=new Object();view.setTag(token);int g=generation;
    decoder.execute(()->{
      try {
        Drawable d=ImageDecoder.decodeDrawable(ImageDecoder.createSource(getResources(),icon.drawable));
        runOnUiThread(()->{
          if(g!=generation||view.getTag()!=token||!foreground)return;
          view.setImageDrawable(d);if(d instanceof AnimatedImageDrawable){((AnimatedImageDrawable)d).setRepeatCount(-1);}
          if(d instanceof Animatable){running.add(d);((Animatable)d).start();}
        });
      }catch(Exception e){/* The static thumbnail remains available. */}
    });
  }
  void freeze(ImageView view,Catalog.Icon icon) {
    view.setTag(null);Drawable d=view.getDrawable();if(d instanceof Animatable)((Animatable)d).stop();
    running.remove(d);view.setImageResource(icon.thumb);
  }
  void home() {
    mono("■  ANDROID TV EDITION",40,109,380,RED);
    label("A LITTLE\nSIGNAL",40,143,430,111,49,INK,true).setLineSpacing(0,.93f);
    chromatic("INTERFERENCE.",40,249,455,64,42);
    label("Your favourite icons. A whole new frequency.\nAnimated artwork with RGB splits and faded reflections.",
      40,324,426,44,13,MUTED,false).setLineSpacing(px(4),1);
    button("Browse collection  →",40,384,206,44,true,()->show(1,null)).setTag("primary");
    button("Apply icon pack",260,384,169,44,false,()->show(2,null));
    mono("●  LIVE PREVIEW",511,112,240,RED);mono("09 SIGNALS",827,112,100,MUTED);
    String[] ids={"ic_netflix","ic_disneyplus","ic_primevideo","ic_appletv","ic_youtube","ic_spotify","ic_plex","ic_kodi","ic_jellyfin"};
    for(int n=0;n<ids.length;n++) {
      Catalog.Icon icon=catalog.find(ids[n]);float x=511+(n%3)*137,y=145+(n/3)*91;
      View tile=new View(this);tile.setBackground(shape(PANEL,LINE,1));place(tile,x,y,131,84);
      ImageView img=image(icon.thumb,x+5,y+6,121,68);animate(img,icon);
    }
    mono("ORIGINAL ARTWORK  /  ORIGINAL TIMING",511,431,409,MUTED);
    line(40,455,880);
    String[] vals={String.format(Locale.US,"%,d",catalog.icons.size()),"320 × 180","RGB + REFLECTION","2 SECOND HOLD"};
    String[] labs={"ICONS","ARTWORK SIZE","ANIMATION","RETURN FRAME"};
    for(int n=0;n<4;n++){mono(labs[n],40+n*225,466,210,MUTED);label(vals[n],40+n*225,480,215,20,12,INK,true);}
  }
  void library() {
    filtered=catalog.filter(query,category,reverse);int pages=Math.max(1,(filtered.size()+9)/10);page=Math.min(page,pages-1);
    mono(picking?"CHOOSE YOUR ICON":"THE COLLECTION",40,105,600,CYAN);
    label("Find your frequency.",40,127,650,42,30,INK,true);
    mono(String.format(Locale.US,"%,d ICONS",filtered.size()),805,143,120,MUTED);
    Button search=button(query.isEmpty()?"Search all icons…":"Search: "+query,40,178,366,36,false,this::searchDialog);search.setTag("search");
    Button cats=button(category+"  ▾",418,178,210,36,false,this::categoryDialog);cats.setTag("category");
    Button sort=button(reverse?"Sort: Z → A":"Sort: A → Z",640,178,160,36,false,()->{reverse=!reverse;page=0;show(1,"sort");});sort.setTag("sort");
    button("Reset",812,178,108,36,false,()->{query="";category="All categories";page=0;reverse=false;show(1,"search");});
    int end=Math.min(filtered.size(),(page+1)*10);
    for(int n=page*10;n<end;n++) {
      Catalog.Icon icon=filtered.get(n);int local=n%10;float x=40+(local%5)*179,y=230+(local/5)*119;
      FrameLayout card=new FrameLayout(this);card.setId(View.generateViewId());card.setFocusable(true);card.setClickable(true);
      card.setBackground(shape(PANEL,LINE,1));card.setContentDescription(icon.label+", "+icon.category+", preview icon");
      card.setTag(icon.id);place(card,x,y,164,109);
      ImageView img=new ImageView(this);img.setScaleType(ImageView.ScaleType.FIT_CENTER);img.setImageResource(icon.thumb);images.add(img);
      FrameLayout.LayoutParams ip=new FrameLayout.LayoutParams(px(150),px(77));ip.leftMargin=px(7);ip.topMargin=px(3);card.addView(img,ip);
      TextView name=text(icon.label,11,INK,true);name.setSingleLine(true);name.setEllipsize(TextUtils.TruncateAt.END);
      FrameLayout.LayoutParams np=new FrameLayout.LayoutParams(px(144),px(23));np.leftMargin=px(10);np.topMargin=px(83);card.addView(name,np);
      card.setOnFocusChangeListener((v,f)->{card.setBackground(shape(PANEL,f?CYAN:LINE,f?2:1));name.setTextColor(f?CYAN:INK);
        if(f){lastFocusedIcon=icon.id;animate(img,icon);}else freeze(img,icon);});
      card.setOnClickListener(v->{selected=icon;previewReturn=1;show(4,null);});cards.add(card);
    }
    if(filtered.isEmpty()) {
      label("No signals found.",40,282,880,46,26,INK,true);
      label("Try a different name or reset the filters.",40,334,880,40,15,MUTED,false);
    }
    previous=button("← Previous",40,473,140,25,false,()->{if(page>0){page--;show(1,null);}});
    next=button("Next →",780,473,140,25,false,()->{if((page+1)*10<filtered.size()){page++;show(1,null);}});
    previous.setEnabled(page>0);previous.setAlpha(page>0?1:.3f);next.setEnabled((page+1)*10<filtered.size());next.setAlpha(next.isEnabled()?1:.3f);
    TextView pageLabel=label("PAGE "+(page+1)+" / "+pages,350,480,260,22,10,MUTED,false);pageLabel.setGravity(Gravity.CENTER);
    for(int n=0;n<cards.size();n++) {
      View c=cards.get(n);int col=n%5;
      c.setNextFocusUpId(n>=5?cards.get(n-5).getId():search.getId());
      c.setNextFocusDownId(n+5<cards.size()?cards.get(n+5).getId():(next.isEnabled()?next.getId():search.getId()));
      c.setNextFocusLeftId(col>0?cards.get(n-1).getId():c.getId());
      c.setNextFocusRightId(col<4&&n+1<cards.size()?cards.get(n+1).getId():c.getId());
    }
    if(!cards.isEmpty()){search.setNextFocusDownId(cards.get(0).getId());cats.setNextFocusDownId(cards.get(Math.min(2,cards.size()-1)).getId());
      sort.setNextFocusDownId(cards.get(Math.min(4,cards.size()-1)).getId());
      previous.setNextFocusUpId(cards.get(Math.min(5,cards.size()-1)).getId());next.setNextFocusUpId(cards.get(cards.size()-1).getId());}
  }
  void searchDialog() {
    EditText input=new EditText(this);input.setSingleLine(true);input.setText(query);input.setHint("Icon name");input.setTextColor(INK);
    AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Search collection").setView(input)
      .setPositiveButton("Search",(d,w)->{query=input.getText().toString();page=0;show(1,"search");})
      .setNegativeButton("Cancel",null).setNeutralButton("Clear",(d,w)->{query="";page=0;show(1,"search");}).create();
    dialog.setOnShowListener(d->{input.requestFocus();input.setSelection(input.length());
      dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);});dialog.show();
  }
  void categoryDialog() {
    String[] choices=catalog.categories.toArray(new String[0]);
    new AlertDialog.Builder(this).setTitle("Choose a category").setSingleChoiceItems(choices,catalog.categories.indexOf(category),(d,n)->{
      category=choices[n];page=0;d.dismiss();show(1,"category");}).setNegativeButton("Cancel",null).show();
  }
  void detail() {
    if(selected==null){show(1,null);return;}
    mono("ICON PREVIEW  /  "+selected.category.toUpperCase(Locale.ROOT),40,109,850,CYAN);
    View panel=new View(this);panel.setBackground(shape(PANEL,LINE,1));place(panel,40,153,541,305);
    ImageView img=image(selected.thumb,57,164,507,285);animate(img,selected);
    TextView title=label(selected.label,617,154,303,96,30,INK,true);title.setMaxLines(2);title.setEllipsize(TextUtils.TruncateAt.END);
    mono("320 × 180  /  ANIMATED WEBP",617,262,307,MUTED);
    label("RGB splits. Faded reflections.\nSix frames, with a two-second\nhold on the return frame.",617,292,307,76,14,MUTED,false).setLineSpacing(px(5),1);
    button(picking?"Use this icon":"Apply icon pack",617,383,303,43,true,()->{if(picking)choose(selected);else show(2,null);}).setTag("detailAction");
    button("← Back to collection",617,441,303,36,false,()->show(previewReturn,lastFocusedIcon));
  }
  void choose(Catalog.Icon icon) {
    Uri uri=Uri.parse("content://"+getPackageName()+".icons/"+icon.id+".webp");
    Intent result=new Intent().setDataAndType(uri,"image/webp").addFlags(
      Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
    result.setClipData(ClipData.newUri(getContentResolver(),icon.label,uri));setResult(RESULT_OK,result);finish();
  }
  boolean launcherInstalled() {
    try{getPackageManager().getPackageInfo(LAUNCHER,0);return true;}catch(Exception e){return false;}
  }
  void applyScreen() {
    mono("MAKE IT YOURS",40,109,850,RED);
    label("A new look.\nOne icon pack.",40,143,480,119,43,INK,true);
    label("Use Glitch Reflections TV with Projectivy Launcher.\nYour animations and reflections stay exactly as designed.",40,292,480,50,14,MUTED,false).setLineSpacing(px(5),1);
    button(launcherInstalled()?"Apply in Projectivy  →":"Open Projectivy in Play Store",40,376,320,44,true,this::applyPack).setTag("primary");
    mono(launcherInstalled()?"PROJECTIVY DETECTED":"PROJECTIVY LAUNCHER REQUIRED",40,438,480,launcherInstalled()?CYAN:MUTED);
    String[] nums={"01","02","03"};String[] titles={"Open launcher settings","Choose the icon pack","Pick a single icon"};
    String[] desc={"Appearance → Cards → Icon pack", "Select Glitch Reflections TV.","Use the launcher's custom icon picker\nto choose any artwork in the collection."};
    for(int n=0;n<3;n++) {float y=140+n*112;line(563,y+92,357);mono(nums[n],563,y,42,RED);
      label(titles[n],608,y,312,30,18,INK,true);label(desc[n],608,y+35,312,49,13,MUTED,false).setLineSpacing(px(4),1);}
  }
  void applyPack() {
    if(!launcherInstalled()){openUrl("market://details?id="+LAUNCHER);return;}
    String[] actions={"tv.projectivy.APPLY_ICONPACK","com.spocky.projengmenu.APPLY_ICONPACK",Intent.ACTION_APPLICATION_PREFERENCES};
    for(String action:actions)try{
      Intent intent=new Intent(action).setPackage(LAUNCHER);
      intent.putExtra("com.spocky.projengmenu.extra.ICONPACK_PACKAGENAME",getPackageName());startActivity(intent);return;
    }catch(ActivityNotFoundException|SecurityException ignored){}
    new AlertDialog.Builder(this).setTitle("Apply Glitch Reflections TV")
      .setMessage("In Projectivy, open Settings → Appearance → Cards → Icon pack, then choose Glitch Reflections TV.")
      .setPositiveButton("Open launcher",(d,w)->{
        Intent intent=getPackageManager().getLeanbackLaunchIntentForPackage(LAUNCHER);
        if(intent==null)intent=getPackageManager().getLaunchIntentForPackage(LAUNCHER);
        if(intent!=null)try{startActivity(intent);}catch(Exception e){Toast.makeText(this,"Open Projectivy Launcher from your TV home screen.",1).show();}
      }).setNegativeButton("Back",null).show();
  }
  void support() {
    mono("SUPPORT THE CREATOR",40,109,600,CYAN);
    label("Keep the\nsignal alive.",40,150,540,128,48,INK,true);
    label("If these icons made your TV feel a little more yours,\nyou can support the next collection. Thank you.",40,314,540,53,15,MUTED,false).setLineSpacing(px(5),1);
    button("Support on PayPal  ↗",40,394,245,44,true,()->openUrl("https://www.paypal.com/paypalme/mickyharu")).setTag("primary");
    button("About this pack",300,394,177,44,false,this::about);
    mono("DONATIONS ARE OPTIONAL. ALL ICONS ARE INCLUDED.",40,462,570,MUTED);
    View white=new View(this);white.setBackgroundColor(0xffffffff);place(white,662,150,230,230);
    image(R.drawable.support_paypal_qr,670,158,214,214);
    TextView scan=label("Scan with your phone",644,402,266,24,14,INK,true);scan.setGravity(Gravity.CENTER);
    TextView address=label("paypal.me/mickyharu",630,435,294,25,12,CYAN,false);address.setGravity(Gravity.CENTER);
  }
  void about() {
    new AlertDialog.Builder(this).setTitle("Glitch Reflections TV · 2.0.0")
      .setMessage("1,195 animated icons • 320 × 180\n\nCreated by MYKLHARU.\nWebsite: myklharu.github.io/glitch-icons\n\nSix-frame animations with RGB glitches, transparent backgrounds, faded reflections, and a two-second return frame.\n\nAndroid TV 9 or later. This TV edition installs separately from the original Glitch Reflections app.\n\nBrand names and logos belong to their respective owners. This independent icon pack is not affiliated with those brands or with Projectivy Launcher.")
      .setPositiveButton("Close",null).show();
  }
  void openUrl(String url) {try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}
    catch(ActivityNotFoundException e){new AlertDialog.Builder(this).setTitle("Open on your phone")
      .setMessage(url.startsWith("market:")?"Install Projectivy Launcher from your TV's app store.":"Scan the QR code or visit paypal.me/mickyharu on your phone.")
      .setPositiveButton("OK",null).show();}}
  @Override public void onBackPressed() {
    if(screen==4){show(previewReturn,lastFocusedIcon);return;}
    if(screen!=0&&!picking){show(0,null);return;}super.onBackPressed();
  }
  @Override protected void onPause(){super.onPause();foreground=false;for(Drawable d:running)if(d instanceof Animatable)((Animatable)d).stop();}
  @Override protected void onResume(){super.onResume();foreground=true;if(motion)for(Drawable d:running)if(d instanceof Animatable)((Animatable)d).start();}
  @Override protected void onDestroy(){stopImages();decoder.shutdownNow();super.onDestroy();}
}
