package dev.glitchreflections.tv;

import android.content.*;
import android.content.res.AssetFileDescriptor;
import android.database.*;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import org.json.JSONObject;
import java.io.*;

/** Public, read-only artwork provider. It exposes only the explicit icon alias index. */
public final class IconProvider extends ContentProvider {
  private JSONObject index;
  @Override public boolean onCreate() {
    try {index=new JSONObject(Catalog.read(getContext(),"native-resources.json"));return true;}
    catch(Exception e) {return false;}
  }
  private String name(Uri uri) throws FileNotFoundException {
    String n=uri.getLastPathSegment();
    if(uri.getPathSegments().size()!=1 || n==null || !n.matches("ic_[a-z0-9_]+\\.(webp|png)"))
      throw new FileNotFoundException("Unknown icon");
    return n.substring(0,n.lastIndexOf('.'));
  }
  private int resource(Uri uri) throws FileNotFoundException {
    String mapped=index==null?"":index.optString(name(uri),"");
    int r=getContext().getResources().getIdentifier(mapped,"drawable",getContext().getPackageName());
    if(r==0) throw new FileNotFoundException("Unknown icon");return r;
  }
  private void readOnly(String mode) throws FileNotFoundException {
    if(!"r".equals(mode)&&!"rt".equals(mode)) throw new FileNotFoundException("Read-only artwork");
  }
  @Override public AssetFileDescriptor openAssetFile(Uri uri,String mode) throws FileNotFoundException {
    readOnly(mode);return getContext().getResources().openRawResourceFd(resource(uri));
  }
  @Override public synchronized ParcelFileDescriptor openFile(Uri uri,String mode) throws FileNotFoundException {
    readOnly(mode);int r=resource(uri);
    File dir=new File(getContext().getCacheDir(),"icons");
    if(!dir.isDirectory()&&!dir.mkdirs()) throw new FileNotFoundException("Icon cache unavailable");
    File file=new File(dir,name(uri)+".webp");
    if(!file.isFile()) try(InputStream in=getContext().getResources().openRawResource(r);
      OutputStream out=new FileOutputStream(file)) {
      byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1) out.write(buffer,0,n);
    } catch(IOException e) {file.delete();throw new FileNotFoundException("Icon unavailable");}
    return ParcelFileDescriptor.open(file,ParcelFileDescriptor.MODE_READ_ONLY);
  }
  @Override public Cursor query(Uri uri,String[] projection,String selection,String[] args,String order) {
    try(AssetFileDescriptor fd=openAssetFile(uri,"r")) {
      String[] cols=projection==null?new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE}:projection;
      MatrixCursor c=new MatrixCursor(cols,1);Object[] row=new Object[cols.length];
      for(int n=0;n<cols.length;n++) {
        if(cols[n].equals(OpenableColumns.DISPLAY_NAME))row[n]=name(uri)+".webp";
        if(cols[n].equals(OpenableColumns.SIZE))row[n]=fd.getLength();
      }
      c.addRow(row);return c;
    } catch(IOException e) {return null;}
  }
  @Override public String getType(Uri uri) {return "image/webp";}
  @Override public Uri insert(Uri uri,ContentValues v) {throw new UnsupportedOperationException("Read-only");}
  @Override public int update(Uri uri,ContentValues v,String s,String[] a) {throw new UnsupportedOperationException("Read-only");}
  @Override public int delete(Uri uri,String s,String[] a) {throw new UnsupportedOperationException("Read-only");}
}
