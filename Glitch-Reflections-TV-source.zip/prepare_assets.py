"""Restore the exact original artwork from its public release, with a pinned digest.

Run before build.sh when building from the compact source archive.
"""
from pathlib import Path
import hashlib, json, urllib.request, zipfile

ROOT=Path(__file__).resolve().parent
APK=ROOT/'original-artwork.apk'
URL='https://github.com/MYKLHARU/glitch-icons/releases/download/v1.0.1/Glitch-Reflections.apk'
SHA='a808c0d946f6d3531e79191dcada2bf8f093e4c9d00d38a9c128efa353e694a0'
if not APK.is_file():
    print('Downloading original artwork (218 MB)…')
    urllib.request.urlretrieve(URL,APK)
if hashlib.file_digest(APK.open('rb'),'sha256').hexdigest()!=SHA:
    raise ValueError('Original APK digest mismatch')
with zipfile.ZipFile(APK) as z:
    for name in z.namelist():
        base=Path(name).name
        if (name.startswith('res/drawable-nodpi') and
            (base.endswith('.webp') or base.startswith('thumb_') and base.endswith('.png'))):
            target=ROOT/'res/drawable-nodpi'/base
            target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(z.read(name))
print('Original artwork restored.')
