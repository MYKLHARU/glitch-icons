# Glitch Reflections — Android TV edition

A native Java Android TV icon-pack application matching the dark charcoal, red, cyan,
and bold typographic style of https://myklharu.github.io/glitch-icons/.

- 1,196 six-frame animated WebP resources and original thumbnails.
- D-pad navigation, searchable and category-filtered catalogue, ten icons per page.
- Focused animated cards, full artwork preview, persistent motion toggle.
- Projectivy icon-pack discovery, appfilter mappings, Apply intents, and read-only icon picker/provider.
- PayPal and Ko-fi support links, with a phone-scannable PayPal QR code.
- No network, storage, analytics, or other runtime permissions. Links open external applications.

Requires **Android TV 5 / API 21 or later**, matching the original pack's minimum.
Android 5–8 play the original lossless WebP frames with their existing blend/disposal
and duration settings. Android 9 and later retain native animated WebP decoding.
App ID: `dev.glitchreflections.tv`. Version: `2.0.3-tv` (103).
This edition installs alongside the original `dev.glitchreflections.iconpack` app.
The original app's private signing key was not part of the supplied APK.

## Build

Use JDK 17 and Android SDK Build Tools 35.0.0 with API 35:

```sh
python3 prepare_assets.py
export BUILD_TOOLS="$ANDROID_SDK_ROOT/build-tools/35.0.0"
export ANDROID_JAR="$ANDROID_SDK_ROOT/platforms/android-35/android.jar"
bash build.sh
```

The compact source archive omits the large unchanged artwork files. The restore script
downloads the user's existing public release and verifies SHA-256 before extraction.
The resource alias/catalog and plain XML mappings are included in this archive.

Sign the aligned output with the separate private signing backup:

```sh
"$BUILD_TOOLS/apksigner" sign --ks glitch-tv.jks --ks-key-alias glitch-tv \
  --ks-pass file:signing-password.txt \
  --out Glitch-Reflections-TV.apk build/Glitch-Reflections-TV-unsigned.apk
"$BUILD_TOOLS/apksigner" verify --verbose --print-certs Glitch-Reflections-TV.apk
```

Keep the signing backup private and use the same key for future TV edition updates.
Do not commit the keystore or password to a public repository.

## Artwork

Icon artwork, animation timing, transparency and reflections are preserved from the
supplied Glitch Reflections APK. Brand names and logos belong to their respective
owners. This independent pack is not affiliated with those brands or Projectivy.
No automatic update checker or installer is included.

## Compatibility validation

`verify_tv.py` checks remote navigation, searching, filtering, playback, motion settings,
support links and the icon picker/provider on a running Android TV emulator.
`verify_legacy_frames.py` decodes all 1,196 animations on-device, checks six frames,
the identical return frame and its 2,000 ms hold, and compares rendered samples
against Pillow. Its disposable test APK is not part of the release.

This compatibility candidate restores a confirmed minimum-SDK regression from 2.0.1.
The physical Shield's generic installation error has not yet been captured, so the
minimum-SDK change is not claimed as a confirmed diagnosis of that device.

## MyAEW icon addition

Version 2.0.3-tv (103) adds MyAEW under Sports as an automatically matched icon.
The Android / Google TV component is
`com.kiswe.androidtv.myaew/com.kiswe.androidtvlive.ui.ContainerActivity`, verified
from MyAEW 2.5.14 (156). Both appfilter XML files, the catalogue, the picker XML,
the provider alias index and thumbnail are updated. All 1,195 previous animations
and 2,120 previous component mappings are preserved.

The new icon preserves the approved transparent 320 × 180 APNG's visible pixels,
frame timings and reflection in the app's lossless animated WebP format. The
original APNG is stored separately in the repository at `icons/MY-AEW-Glitch.apng`.
It follows the uploaded Netflix reference's four glitch stages, with a copied
first frame held for 2,000 ms at the end. The reflection is mirrored at the
logo's proportions and faded, without vertical compression.

The 2.0.3 source builds successfully. Publishing an installable update requires
the existing private TV signing key; no replacement key or unsigned release
should be distributed as a TV update.
