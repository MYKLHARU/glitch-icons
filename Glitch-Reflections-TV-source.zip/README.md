# Glitch Reflections — Android TV edition

A native Java Android TV icon-pack application matching the dark charcoal, red, cyan,
and bold typographic style of https://myklharu.github.io/glitch-icons/.

- 1,195 original six-frame animated WebP resources and original thumbnails.
- D-pad navigation, searchable and category-filtered catalogue, ten icons per page.
- Focused animated cards, full artwork preview, persistent motion toggle.
- Projectivy icon-pack discovery, appfilter mappings, Apply intents, and read-only icon picker/provider.
- PayPal support link and phone-scannable QR code.
- No network, storage, analytics, or other runtime permissions. Links open external applications.

Requires **Android TV 9 / API 28 or later** for native animated WebP decoding.
App ID: `dev.glitchreflections.tv`. Version: `2.0.0-tv` (100).
This edition installs alongside the original `dev.glitchreflections.iconpack` app.
The original app's private signing key was not part of the supplied APK.

## Build

Use JDK 17 and Android SDK Build Tools 35.0.0 with API 35:

```sh
python3 prepare_assets.py
export BUILD_TOOLS="$ANDROID_SDK_ROOT/build-tools/35.0.0"
export ANDROID_JAR="$ANDROID_SDK_ROOT/platforms/android-35/android.jar"
bash build.sh
```

The compact source archive omits the large unchanged artwork files. The restore script
downloads the user's existing public release and verifies SHA-256 before extraction.
The resource alias/catalog and plain XML mappings are included in this archive.

Sign the aligned output with the separate private signing backup:

```sh
"$BUILD_TOOLS/apksigner" sign --ks glitch-tv.jks --ks-key-alias glitch-tv \
  --ks-pass file:signing-password.txt \
  --out Glitch-Reflections-TV.apk build/Glitch-Reflections-TV-unsigned.apk
"$BUILD_TOOLS/apksigner" verify --verbose --print-certs Glitch-Reflections-TV.apk
```

Keep the signing backup private and use the same key for future TV edition updates.
Do not commit the keystore or password to a public repository.

## Artwork

Icon artwork, animation timing, transparency and reflections are preserved from the
supplied Glitch Reflections APK. Brand names and logos belong to their respective
owners. This independent pack is not affiliated with those brands or Projectivy.
No automatic update checker or installer is included.
