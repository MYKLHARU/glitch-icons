"""Collect both independent checks and diagnostics, including on failure."""
from pathlib import Path
import json,subprocess,sys
out=Path('verification');out.mkdir(exist_ok=True)
results={}
try:
    for script in ['verify_tv.py','verify_legacy_frames.py']:
        results[script]=subprocess.run([sys.executable,script]).returncode
finally:
    for name,command in {
        'final-screen.png':['adb','exec-out','screencap','-p'],
        'final-logcat.txt':['adb','logcat','-d','-t','4000'],
        'final-activity.txt':['adb','shell','dumpsys','activity','activities'],
    }.items():
        result=subprocess.run(command,capture_output=True,timeout=30)
        (out/name).write_bytes(result.stdout+result.stderr)
    (out/'verification-status.json').write_text(json.dumps(results,indent=2))
assert results and all(code==0 for code in results.values()),results
