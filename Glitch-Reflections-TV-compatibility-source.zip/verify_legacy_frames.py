"""Run the legacy decoder on-device, then compare rendered samples with Pillow.

The throwaway test APK is separate from the release and is never published.
"""
from pathlib import Path
import json, os, re, subprocess, time, zipfile
import numpy as np
from PIL import Image

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'verification/legacy-frames';OUT.mkdir(parents=True,exist_ok=True)
WORK=ROOT/'build/frame-check';WORK.mkdir(parents=True,exist_ok=True)
SDK=Path(os.environ.get('ANDROID_HOME','/usr/local/lib/android/sdk'))
TOOLS=Path(os.environ.get('BUILD_TOOLS',SDK/'build-tools/35.0.0'))
ANDROID=Path(os.environ.get('ANDROID_JAR',SDK/'platforms/android-35/android.jar'))
PROBE='dev.glitchreflections.animationcheck'
TARGET='dev.glitchreflections.tv'

def run(*args):
    return subprocess.check_output(list(map(str,args)),stderr=subprocess.STDOUT,timeout=180)
def adb(*args):return run('adb',*args)

java=r'''package dev.glitchreflections.tv;
import android.app.Activity; import android.os.Bundle; import android.content.Context;
import android.graphics.Bitmap; import java.io.*; import org.json.*;
public class FrameCheckActivity extends Activity {
  protected void onCreate(Bundle state){super.onCreate(state);new Thread(()->check()).start();}
  void check(){
    JSONObject report=new JSONObject();
    try {
      Context target=createPackageContext("dev.glitchreflections.tv",0);
      ByteArrayOutputStream bytes=new ByteArrayOutputStream();
      try(InputStream in=target.getAssets().open("catalog.json")){byte[] buffer=new byte[8192];int n;while((n=in.read(buffer))!=-1)bytes.write(buffer,0,n);}
      JSONArray icons=new JSONObject(new String(bytes.toByteArray(),"UTF-8")).getJSONArray("icons");
      JSONArray saved=new JSONArray();int count=0;
      for(int n=0;n<icons.length();n++) {
        JSONObject icon=icons.getJSONObject(n);String resource=icon.getString("resource");
        int id=target.getResources().getIdentifier(resource,"drawable",target.getPackageName());
        FrameSequenceDrawable drawable=FrameSequenceDrawable.decode(target.getResources(),id);
        if(drawable.frames.length!=6||drawable.getIntrinsicWidth()!=320||drawable.getIntrinsicHeight()!=180)throw new IOException("Wrong frames or dimensions: "+resource);
        if(drawable.durations[5]!=2000)throw new IOException("Return hold changed: "+resource);
        if(!drawable.frames[0].sameAs(drawable.frames[5]))throw new IOException("Return frame changed: "+resource);
        if(n%80==0||icon.getString("id").equals("ic_netflix")) {
          JSONObject sample=new JSONObject();sample.put("resource",resource);sample.put("index",n);
          JSONArray timings=new JSONArray();for(int duration:drawable.durations)timings.put(duration);sample.put("durations",timings);
          for(int f=0;f<drawable.frames.length;f++)try(OutputStream out=new FileOutputStream(new File(getFilesDir(),n+"-"+f+".png"))){drawable.frames[f].compress(Bitmap.CompressFormat.PNG,100,out);}
          saved.put(sample);
        }
        for(Bitmap bitmap:drawable.frames)bitmap.recycle();count++;
        if(n%50==0)System.gc();
      }
      report.put("decoded",count);report.put("samples",saved);report.put("success",true);
    }catch(Throwable error){try{report.put("success",false);report.put("error",android.util.Log.getStackTraceString(error));}catch(Exception ignored){}}
    try(OutputStream out=new FileOutputStream(new File(getFilesDir(),"report.json"))){out.write(report.toString(2).getBytes("UTF-8"));}catch(Exception ignored){}
    runOnUiThread(()->finish());
  }
}'''
manifest='''<manifest xmlns:android="http://schemas.android.com/apk/res/android" package="dev.glitchreflections.animationcheck" android:versionCode="1"><uses-sdk android:minSdkVersion="21" android:targetSdkVersion="28"/><application android:label="Emulator frame verification" android:debuggable="true"><activity android:name="dev.glitchreflections.tv.FrameCheckActivity" android:exported="true"/></application></manifest>'''
(WORK/'FrameCheckActivity.java').write_text(java)
(WORK/'AndroidManifest.xml').write_text(manifest)
(WORK/'classes').mkdir(exist_ok=True);(WORK/'dex').mkdir(exist_ok=True)
run(TOOLS/'aapt2','link','--manifest',WORK/'AndroidManifest.xml','-I',ANDROID,'-o',WORK/'unsigned.apk')
run('java','-m','jdk.compiler/com.sun.tools.javac.Main','-source','8','-target','8','-bootclasspath',str(TOOLS/'core-lambda-stubs.jar')+':'+str(ANDROID),'-d',WORK/'classes',WORK/'FrameCheckActivity.java',ROOT/'src/dev/glitchreflections/tv/FrameSequenceDrawable.java')
run('java','-m','jdk.jartool/sun.tools.jar.Main','--create','--file',WORK/'classes.jar','-C',WORK/'classes','.')
run(TOOLS/'d8','--min-api','21','--lib',ANDROID,'--output',WORK/'dex',WORK/'classes.jar')
with zipfile.ZipFile(WORK/'unsigned.apk','a') as z:z.write(WORK/'dex/classes.dex','classes.dex',compress_type=zipfile.ZIP_DEFLATED)
run(TOOLS/'zipalign','-f','4',WORK/'unsigned.apk',WORK/'aligned.apk')
run(TOOLS/'apksigner','sign','--ks',ROOT/'build/test.jks','--ks-pass','pass:android','--out',WORK/'probe.apk',WORK/'aligned.apk')
adb('shell','am','force-stop',TARGET)
adb('install','-r',WORK/'probe.apk')
adb('shell','am','start','-n',PROBE+'/dev.glitchreflections.tv.FrameCheckActivity')
for attempt in range(150):
    result=subprocess.run(['adb','exec-out','run-as',PROBE,'cat','files/report.json'],capture_output=True,timeout=15)
    # exec-out can exit successfully while the remote cat reports a missing file.
    # Wait for a complete JSON report instead of treating that message as results.
    try:
        report=json.loads(result.stdout)
        if isinstance(report,dict) and 'success' in report:break
    except (ValueError,UnicodeError):pass
    time.sleep(2)
else:raise RuntimeError('Frame verification did not finish in five minutes')
(OUT/'device-report.json').write_bytes(result.stdout)
assert report.get('success'),report
assert report['decoded']==1195,report
maximum=0
for sample in report['samples']:
    resource=sample['resource'];index=sample['index']
    with Image.open(ROOT/'res/drawable-nodpi'/(resource+'.webp')) as original:
        for f,duration in enumerate(sample['durations']):
            original.seek(f)
            expected=np.asarray(original.convert('RGBA')).astype(np.int32)
            assert original.info['duration']==duration,(resource,f,'duration')
            data=adb('exec-out','run-as',PROBE,'cat','files/'+str(index)+'-'+str(f)+'.png')
            target=OUT/(str(index)+'-'+str(f)+'.png');target.write_bytes(data)
            with Image.open(target) as im:actual=np.asarray(im.convert('RGBA')).astype(np.int32)
            # Compare visible premultiplied colour: fully transparent RGB is immaterial.
            assert np.array_equal(expected[:,:,3],actual[:,:,3]),(resource,f,'alpha changed')
            rgb_expected=(expected[:,:,:3]*expected[:,:,3:]+127)//255
            rgb_actual=(actual[:,:,:3]*actual[:,:,3:]+127)//255
            difference=int(np.abs(rgb_expected-rgb_actual).max());maximum=max(maximum,difference)
            assert difference<=2,(resource,f,'colour changed',difference)
summary={'decoded_icons':report['decoded'],'compared_frames':len(report['samples'])*6,'maximum_premultiplied_colour_difference':maximum,'six_frames':True,'return_frame_identical':True,'return_hold_ms':2000}
(OUT/'comparison.json').write_text(json.dumps(summary,indent=2))
print('PASS: legacy animation verification',json.dumps(summary),flush=True)
adb('uninstall',PROBE)
