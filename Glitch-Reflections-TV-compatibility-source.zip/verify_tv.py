"""Instrumented smoke checks against a running Android TV emulator, using adb."""
from pathlib import Path
import hashlib, json, re, subprocess, time, xml.etree.ElementTree as ET

OUT=Path('verification');OUT.mkdir(exist_ok=True)
PACKAGE='dev.glitchreflections.tv'
checks=[]
def adb(*args, binary=False):
    return subprocess.check_output(['adb',*args],timeout=60,**({} if binary else {'text':True}))
def key(code):
    adb('shell','input','keyevent',str(code));time.sleep(.25)
def tree(name=None):
    for attempt in range(3):
        adb('shell','rm','-f','/data/local/tmp/window.xml')
        try:
            result=adb('shell','uiautomator','dump','--compressed','/data/local/tmp/window.xml')
            xml=adb('shell','cat','/data/local/tmp/window.xml')
            parsed=ET.fromstring(xml)
            if 'ERROR' not in result and 'null root' not in result:break
        except (subprocess.CalledProcessError,ET.ParseError):pass
        time.sleep(.2)
    else:
        (OUT/'hierarchy-error.txt').write_text(str(locals().get('result',''))+'\n'+str(locals().get('xml','')))
        shot('hierarchy-failure')
        (OUT/'logcat.txt').write_text(adb('logcat','-d','-t','3000'))
        raise AssertionError('Could not obtain a fresh UI hierarchy')
    if name:(OUT/(name+'.xml')).write_text(xml)
    return parsed
def shot(name):
    (OUT/(name+'.png')).write_bytes(adb('exec-out','screencap','-p',binary=True))
def contains(t,text):
    return any(text in n.get('text','') or text in n.get('content-desc','') for n in t.iter('node'))
def assert_check(value,description):
    if not value:shot('failure')
    assert value,description;checks.append(description);print('PASS:',description,flush=True)
def tap(t,text):
    nodes=[n for n in t.iter('node') if n.get('text','').casefold()==text.casefold()]
    if not nodes:nodes=[n for n in t.iter('node') if text in n.get('text','')]
    assert nodes,'Missing text: '+text
    n=nodes[0];a,b,c,d=map(int,re.findall(r'\d+',n.get('bounds','')))
    adb('shell','input','tap',str((a+c)//2),str((b+d)//2));time.sleep(.5)
def focused(t):
    return next((n for n in t.iter('node') if n.get('focused')=='true'),None)

adb('shell','am','force-stop',PACKAGE)
adb('shell','am','start','-n',PACKAGE+'/.MainActivity');time.sleep(3)
t=tree('01-home');shot('01-home')
assert_check(contains(t,'INTERFERENCE.'),'Home screen rendered')
assert_check(focused(t) is not None and focused(t).get('text')=='Browse collection  →','Initial remote focus on Browse collection')
key(23);t=tree('02-collection');shot('02-collection')
assert_check(contains(t,'Find your frequency.'),'D-pad Select opens collection')
assert_check(len([n for n in t.iter('node') if ', preview icon' in n.get('content-desc','')])==10,'Ten icon cards rendered')
before=focused(t).get('content-desc');key(22);t=tree()
assert_check(focused(t).get('content-desc')!=before,'D-pad Right moves between icon cards')
key(20);t=tree();selected=focused(t).get('content-desc')
assert_check(selected and selected!=before,'D-pad Down moves to the next row')
key(23);t=tree('03-preview');shot('03-preview')
assert_check(contains(t,'Six frames'),'D-pad Select opens animated artwork preview')
# Sample the live preview across more than one full animation loop.
frames=[]
for n in range(18):
    frame=adb('exec-out','screencap','-p',binary=True);frames.append(hashlib.sha256(frame).hexdigest())
    if n in (0,4,8,12,17):(OUT/('motion-%02d.png'%n)).write_bytes(frame)
    time.sleep(.17)
assert_check(len(set(frames))>1,'Preview visibly animates across captured frames')
key(4);t=tree()
assert_check(focused(t).get('content-desc')==selected,'Back restores the selected icon focus')
tap(t,'Search all icons…');t=tree()
assert_check(contains(t,'Search collection'),'Search opens a native text entry dialog')
adb('shell','input','text','Netflix');tap(tree(),'Search');t=tree('04-search');shot('04-search')
assert_check(contains(t,'Netflix') and contains(t,'Search: Netflix'),'Search filters the collection')
tap(t,'Reset');tap(tree(),'All categories  ▾');t=tree();tap(t,'Sports');t=tree('05-category');shot('05-category')
assert_check(contains(t,'69 ICONS'),'Category filter returns 69 Sports icons')
tap(t,'Reset');t=tree();tap(t,'Next →');t=tree()
assert_check(contains(t,'PAGE 2 / 120'),'Pagination opens the next set of ten icons')
tap(t,'Motion: on');t=tree()
assert_check(contains(t,'Motion: off'),'Motion toggle disables playback')
adb('shell','am','force-stop',PACKAGE);adb('shell','am','start','-n',PACKAGE+'/.MainActivity');time.sleep(1)
t=tree();assert_check(contains(t,'Motion: off'),'Motion preference survives app restart')
tap(t,'Motion: off');tap(tree(),'Apply');t=tree('06-apply');shot('06-apply')
assert_check(contains(t,'One icon pack.'),'Apply screen rendered without Projectivy installed')
assert_check(contains(t,'PROJECTIVY LAUNCHER REQUIRED'),'Apply screen explains the launcher requirement')
tap(t,'Support');t=tree('07-support');shot('07-support')
assert_check(contains(t,'paypal.me/mickyharu'),'Support page contains the correct donation destination')
assert_check(contains(t,'ko-fi.com/myklharu') and contains(t,'Support on Ko-fi'),'Support page includes Ko-fi alongside PayPal')
key(4);t=tree();assert_check(contains(t,'INTERFERENCE.'),'Back from a section returns to Home')
# Confirm the explicit read-only artwork provider returns a genuine animated WebP.
data=adb('exec-out','content','read','--uri','content://'+PACKAGE+'.icons/ic_netflix.webp',binary=True)
(OUT/'provider-netflix.webp').write_bytes(data)
assert_check(data[:4]==b'RIFF' and data[8:12]==b'WEBP' and b'ANIM' in data,'Picker provider exposes animated WebP bytes')
query=adb('shell','content','query','--uri','content://'+PACKAGE+'.icons/ic_netflix.webp')
assert_check('_display_name=ic_netflix.webp' in query and '_size=' in query,'Provider reports filename and file size')
# Explicit Projectivy discovery launch must enter the picker catalogue.
adb('shell','am','force-stop',PACKAGE)
adb('shell','am','start','-a','com.spocky.projengmenu.icons.ACTION_PICK_ICON','-p',PACKAGE);time.sleep(1)
t=tree('08-picker');shot('08-picker')
assert_check(contains(t,'CHOOSE YOUR ICON'),'Projectivy discovery opens picker mode')
assert_check(focused(t) is not None and ', preview icon' in focused(t).get('content-desc',''),'Picker starts with a focused icon after mixed mouse/remote input')
key(23);t=tree();assert_check(contains(t,'Use this icon'),'Picker preview offers the selected icon')
key(23);time.sleep(.5)
resumed=[line for line in adb('shell','dumpsys','activity','activities').splitlines() if 'mResumedActivity:' in line]
assert_check(not any(PACKAGE in line for line in resumed), 'Picker Select returns to caller')
log=adb('logcat','-d','-t','3000');(OUT/'logcat.txt').write_text(log)
app_crash=re.search(r'FATAL EXCEPTION[^\n]*\n[^\n]*Process:\s*'+re.escape(PACKAGE)+r'(?:,|\s)',log)
assert_check(app_crash is None, 'No fatal app exception during smoke checks')
(OUT/'report.json').write_text(json.dumps({'passed':len(checks),'checks':checks},indent=2)+'\n')
print('Passed',len(checks),'TV checks',flush=True)
