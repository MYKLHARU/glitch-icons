package dev.glitchreflections.tv;

import android.content.res.Resources;
import android.graphics.ImageDecoder;
import android.graphics.drawable.AnimatedImageDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import java.io.IOException;

/** Keep Android 9-only classes out of the Activity's legacy code path. */
final class IconAnimation {
  static Drawable decode(Resources resources, int id) throws IOException {
    if(Build.VERSION.SDK_INT>=28)return Modern.decode(resources,id);
    return FrameSequenceDrawable.decode(resources,id);
  }
  private static final class Modern {
    static Drawable decode(Resources resources,int id) throws IOException {
      Drawable drawable=ImageDecoder.decodeDrawable(ImageDecoder.createSource(resources,id));
      if(drawable instanceof AnimatedImageDrawable)((AnimatedImageDrawable)drawable).setRepeatCount(-1);
      return drawable;
    }
  }
}
