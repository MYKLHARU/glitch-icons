package dev.glitchreflections.tv;

import android.content.res.Resources;
import android.graphics.*;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import java.io.*;
import java.util.ArrayList;

/** Plays this pack's lossless WebP frames on Android 5-8 without re-encoding artwork.
 * ANMF offsets, blend/disposal and millisecond durations follow the WebP RIFF spec.
 * Android's existing static WebP decoder handles each unchanged VP8L bitstream.
 */
final class FrameSequenceDrawable extends Drawable implements Animatable,Runnable {
  final Bitmap[] frames;
  final int[] durations;
  private final Paint paint=new Paint(Paint.FILTER_BITMAP_FLAG);
  private int frame;
  private boolean playing;

  private FrameSequenceDrawable(ArrayList<Bitmap> bitmaps,ArrayList<Integer> delays) {
    frames=bitmaps.toArray(new Bitmap[0]);durations=new int[delays.size()];
    for(int n=0;n<durations.length;n++)durations[n]=delays.get(n);
  }
  private static int number(byte[] bytes,int at,int length) {
    int result=0;for(int n=0;n<length;n++)result|=(bytes[at+n]&255)<<(8*n);return result;
  }
  private static boolean tag(byte[] bytes,int at,String tag) {
    for(int n=0;n<4;n++)if(bytes[at+n]!=(byte)tag.charAt(n))return false;return true;
  }
  private static void write32(byte[] bytes,int at,int value) {
    for(int n=0;n<4;n++)bytes[at+n]=(byte)(value>>>(8*n));
  }
  static FrameSequenceDrawable decode(Resources resources,int id) throws IOException {
    ByteArrayOutputStream out=new ByteArrayOutputStream();
    try(InputStream in=resources.openRawResource(id)) {
      byte[] buffer=new byte[8192];int count;
      while((count=in.read(buffer))!=-1){out.write(buffer,0,count);if(out.size()>16*1024*1024)throw new IOException("Artwork too large");}
    }
    byte[] bytes=out.toByteArray();
    if(bytes.length<30||!tag(bytes,0,"RIFF")||!tag(bytes,8,"WEBP"))throw new IOException("Invalid WebP");
    int width=0,height=0,background=0;
    Bitmap canvasBitmap=null;Canvas canvas=null;Rect previous=null;boolean dispose=false;
    ArrayList<Bitmap> frames=new ArrayList<>();ArrayList<Integer> durations=new ArrayList<>();
    Paint clear=new Paint();clear.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC));
    Paint replace=new Paint();replace.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC));
    Paint blend=new Paint();
    try {
      for(int at=12;at+8<=bytes.length;) {
        int size=number(bytes,at+4,4),data=at+8;
        if(size<0||size>bytes.length-data)throw new IOException("Truncated WebP chunk");
        if(tag(bytes,at,"VP8X")) {
          if(size<10)throw new IOException("Invalid WebP canvas");
          width=number(bytes,data+4,3)+1;height=number(bytes,data+7,3)+1;
          if(width>1024||height>1024)throw new IOException("Invalid artwork dimensions");
        } else if(tag(bytes,at,"ANIM")) {
          if(size<6)throw new IOException("Invalid animation header");
          background=number(bytes,data,4);
        } else if(tag(bytes,at,"ANMF")) {
          if(width==0||height==0||size<24||frames.size()>=64)throw new IOException("Invalid animation frame");
          int x=number(bytes,data,3)*2,y=number(bytes,data+3,3)*2;
          int w=number(bytes,data+6,3)+1,h=number(bytes,data+9,3)+1;
          int duration=Math.max(1,number(bytes,data+12,3)),flags=bytes[data+15]&255;
          if(x+w>width||y+h>height||!tag(bytes,data+16,"VP8L"))throw new IOException("Unsupported artwork frame");
          if(canvasBitmap==null) {
            canvasBitmap=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);
            canvas=new Canvas(canvasBitmap);canvas.drawColor(background,PorterDuff.Mode.SRC);
          }
          if(dispose){clear.setColor(background);canvas.drawRect(previous,clear);}
          // Wrap the frame's existing image chunk in a standalone RIFF header.
          byte[] still=new byte[12+size-16];
          still[0]='R';still[1]='I';still[2]='F';still[3]='F';write32(still,4,still.length-8);
          still[8]='W';still[9]='E';still[10]='B';still[11]='P';
          System.arraycopy(bytes,data+16,still,12,size-16);
          Bitmap bitmap=BitmapFactory.decodeByteArray(still,0,still.length);
          if(bitmap==null)throw new IOException("WebP frame could not be decoded");
          try {
            if(bitmap.getWidth()!=w||bitmap.getHeight()!=h)throw new IOException("WebP frame size mismatch");
            canvas.drawBitmap(bitmap,x,y,(flags&2)!=0?replace:blend);
          } finally {bitmap.recycle();}
          frames.add(canvasBitmap.copy(Bitmap.Config.ARGB_8888,false));durations.add(duration);
          previous=new Rect(x,y,x+w,y+h);dispose=(flags&1)!=0;
        }
        at=data+size+(size&1);
      }
      if(frames.isEmpty())throw new IOException("Animation has no frames");
      return new FrameSequenceDrawable(frames,durations);
    } catch(IOException|RuntimeException error) {
      for(Bitmap bitmap:frames)bitmap.recycle();throw error;
    } finally {if(canvasBitmap!=null)canvasBitmap.recycle();}
  }
  @Override public void draw(Canvas canvas){canvas.drawBitmap(frames[frame],null,getBounds(),paint);}
  @Override public int getIntrinsicWidth(){return frames[0].getWidth();}
  @Override public int getIntrinsicHeight(){return frames[0].getHeight();}
  @Override public void setAlpha(int alpha){paint.setAlpha(alpha);invalidateSelf();}
  @Override public void setColorFilter(ColorFilter filter){paint.setColorFilter(filter);invalidateSelf();}
  @Override public int getOpacity(){return PixelFormat.TRANSLUCENT;}
  @Override public boolean isRunning(){return playing;}
  @Override public void start(){if(playing)return;playing=true;invalidateSelf();scheduleSelf(this,SystemClock.uptimeMillis()+durations[frame]);}
  @Override public void stop(){playing=false;unscheduleSelf(this);}
  @Override public void run(){if(!playing)return;frame=(frame+1)%frames.length;invalidateSelf();scheduleSelf(this,SystemClock.uptimeMillis()+durations[frame]);}
}
