#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
: "${ANDROID_JAR:?Set ANDROID_JAR to an API 35 android.jar}"
: "${BUILD_TOOLS:?Set BUILD_TOOLS to the Android SDK build-tools directory}"
mkdir -p build/generated build/classes build/dex
if [[ ! -f build/resources.zip ]] || [[ -n "$(find res -type f -newer build/resources.zip -print -quit)" ]]; then
  "$BUILD_TOOLS/aapt2" compile --no-crunch --dir res -o build/resources.zip
fi
"$BUILD_TOOLS/aapt2" link -I "$ANDROID_JAR" --manifest AndroidManifest.xml \
  --java build/generated -A assets build/resources.zip \
  --no-auto-version -0 webp -0 png -0 arsc -o build/resources.apk
find src build/generated -name '*.java' -print > build/sources.txt
java -m jdk.compiler/com.sun.tools.javac.Main -source 8 -target 8 \
  -bootclasspath "$BUILD_TOOLS/core-lambda-stubs.jar:$ANDROID_JAR" -d build/classes @build/sources.txt
java -m jdk.jartool/sun.tools.jar.Main --create --file build/classes.jar -C build/classes .
"$BUILD_TOOLS/d8" --release --min-api 21 --lib "$ANDROID_JAR" --output build/dex build/classes.jar
cp build/resources.apk build/unsigned.apk
python3 - <<'PY'
import zipfile
with zipfile.ZipFile('build/unsigned.apk','a') as z:
 z.write('build/dex/classes.dex','classes.dex',compress_type=zipfile.ZIP_DEFLATED)
PY
"$BUILD_TOOLS/zipalign" -f -p 4 build/unsigned.apk build/Glitch-Reflections-TV-unsigned.apk
echo 'Built build/Glitch-Reflections-TV-unsigned.apk'
